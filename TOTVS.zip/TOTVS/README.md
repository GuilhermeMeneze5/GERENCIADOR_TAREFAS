# Projeto - Gerenciador de Tarefas
O objetivo desse projeto é criar uma aplicação para o gerenciamento de tarefas, onde uma tarefa pode ter nenhuma ou várias subtarefas. 
Deve permitir ao usuário criar, editar, excluir tarefas e subtarefas. 
As tarefas e subtarefas terão estados para pendente, andamento, concluída ou cancelada.

#Configuração MVC
1. Compile o fonte TVS25.prw
2. Configure o Menu #Gerenciamento de Tarefas 

#Notas
- Toda a tarefa foi desenvolvida em meu tempo livre entre 10/06 e 11/06

#Melhorias Futuras
- Ajuste nas validações e utilização de gatilhos.
- Possibilidade de copiar subtarefas
- Designação de Responsavel baseado em uuarios protheus
